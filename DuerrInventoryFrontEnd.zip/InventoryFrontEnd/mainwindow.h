#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QString userRole, QString userID, QString userPin, QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_loadButton_clicked();

    void on_editButton_clicked();

    void on_deleteButton_clicked();

private:
    Ui::MainWindow *ui;
    QNetworkAccessManager *manager;
    QString currentUserRole;
    QString currentUserID;
    QString currentUserPin;
};
#endif // MAINWINDOW_H
