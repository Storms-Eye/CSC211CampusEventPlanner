#include "additemdialog.h"
#include "ui_additemdialog.h"

AddItemDialog::AddItemDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddItemDialog)
{
    ui->setupUi(this);
    connect(ui->pushButton, &QPushButton::clicked, this, &AddItemDialog::accept);
}

AddItemDialog::~AddItemDialog()
{
    delete ui;
}


QString AddItemDialog::getName()
{
    return ui->lineEdit->text();
}

int AddItemDialog::getQuantity()
{
    return ui->spinBox->value();
}

void AddItemDialog::on_pushButton_clicked()
{
    accept();
}

