#include "login.h"
#include "ui_login.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QDebug>
#include <QMessageBox>

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login),
    manager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);
}

Login::~Login()
{
    delete ui;
}


bool loggedIn = false;  // Variable to track whether user has been logged in
QString userRole, userID, userPin;

void Login::on_loginButton_clicked()
{
    // Obtain User ID and Pin
    QString userIdText = ui->userIdInput->text().trimmed();
    QString pinText = ui->pinInput->text().trimmed();
    userID = userIdText.trimmed();
    userPin = pinText.trimmed();

    // Check to see if ID and pin boxes are filled
    if(userIdText.isEmpty() || pinText.isEmpty())
    {
        QMessageBox::warning(this, "Login Error", "Please enter in both a user ID and a Pin");
        return;
    }

    QJsonObject obj;
    obj["id"] = userIdText;
    obj["pin"] = pinText;

    // Convert user input to JSON data
    QJsonDocument doc(obj);
    QByteArray data = doc.toJson();

    // Login POST request
    QUrl url("http://localhost:18080/login");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QNetworkReply *reply = manager->post(request, data);

    connect(reply, &QNetworkReply::finished, this, [=]()
    {
        // If a reply is received
        if(reply->error() == QNetworkReply::NoError)
        {
            QByteArray responseData = reply->readAll();
            QMessageBox::information(this, "Login Success", "Login Successful.");
            QJsonDocument doc = QJsonDocument::fromJson(responseData);  // Parse received JSON data
            QJsonObject obj = doc.object();
            userRole = obj["role"].toString();
            accept();
        }

        else
        {
            QMessageBox::warning(this, "POST Login failed", reply->errorString());
        }

        reply->deleteLater();
    });

}

bool Login::isLoggedIn()
{
    return loggedIn;
}

QString Login::getUserRole()
{
    return userRole;
}

QString Login::getUserID()
{
    return userID;
}

QString Login::getUserPin()
{
    return userPin;
}

