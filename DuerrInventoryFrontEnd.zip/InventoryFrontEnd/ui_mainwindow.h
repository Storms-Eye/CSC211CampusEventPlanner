/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QPlainTextEdit *outputBox;
    QPushButton *loadButton;
    QPushButton *editButton;
    QLineEdit *idInput;
    QSpinBox *editQtySpinBox;
    QPushButton *deleteButton;
    QLineEdit *deleteItemIdInput;
    QLabel *currentRoleLabel;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(940, 695);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(70, 150, 181, 61));
        outputBox = new QPlainTextEdit(centralwidget);
        outputBox->setObjectName(QString::fromUtf8("outputBox"));
        outputBox->setGeometry(QRect(210, 380, 471, 221));
        loadButton = new QPushButton(centralwidget);
        loadButton->setObjectName(QString::fromUtf8("loadButton"));
        loadButton->setGeometry(QRect(330, 290, 181, 61));
        editButton = new QPushButton(centralwidget);
        editButton->setObjectName(QString::fromUtf8("editButton"));
        editButton->setGeometry(QRect(580, 150, 181, 61));
        idInput = new QLineEdit(centralwidget);
        idInput->setObjectName(QString::fromUtf8("idInput"));
        idInput->setGeometry(QRect(590, 30, 161, 31));
        editQtySpinBox = new QSpinBox(centralwidget);
        editQtySpinBox->setObjectName(QString::fromUtf8("editQtySpinBox"));
        editQtySpinBox->setGeometry(QRect(590, 90, 161, 31));
        deleteButton = new QPushButton(centralwidget);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));
        deleteButton->setGeometry(QRect(330, 150, 181, 61));
        deleteItemIdInput = new QLineEdit(centralwidget);
        deleteItemIdInput->setObjectName(QString::fromUtf8("deleteItemIdInput"));
        deleteItemIdInput->setGeometry(QRect(340, 100, 161, 31));
        currentRoleLabel = new QLabel(centralwidget);
        currentRoleLabel->setObjectName(QString::fromUtf8("currentRoleLabel"));
        currentRoleLabel->setGeometry(QRect(290, 30, 221, 21));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        currentRoleLabel->setFont(font);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 940, 29));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Add Item", nullptr));
        loadButton->setText(QCoreApplication::translate("MainWindow", "Load All Items", nullptr));
        editButton->setText(QCoreApplication::translate("MainWindow", "Edit Quantity", nullptr));
        idInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter ID Here", nullptr));
        deleteButton->setText(QCoreApplication::translate("MainWindow", "Delete Item", nullptr));
        deleteItemIdInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter ID Here", nullptr));
        currentRoleLabel->setText(QCoreApplication::translate("MainWindow", "Current Role: ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
