/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QLineEdit *pinInput;
    QLineEdit *userIdInput;
    QPushButton *loginButton;
    QLabel *label;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QString::fromUtf8("Login"));
        Login->resize(547, 430);
        pinInput = new QLineEdit(Login);
        pinInput->setObjectName(QString::fromUtf8("pinInput"));
        pinInput->setGeometry(QRect(160, 210, 161, 31));
        pinInput->setEchoMode(QLineEdit::Password);
        userIdInput = new QLineEdit(Login);
        userIdInput->setObjectName(QString::fromUtf8("userIdInput"));
        userIdInput->setGeometry(QRect(160, 150, 161, 31));
        userIdInput->setEchoMode(QLineEdit::Normal);
        loginButton = new QPushButton(Login);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));
        loginButton->setGeometry(QRect(160, 280, 181, 61));
        label = new QLabel(Login);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(170, 60, 151, 31));
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QCoreApplication::translate("Login", "Dialog", nullptr));
        pinInput->setInputMask(QString());
        pinInput->setPlaceholderText(QCoreApplication::translate("Login", "Enter User Pin Here", nullptr));
        userIdInput->setPlaceholderText(QCoreApplication::translate("Login", "Enter User ID Here", nullptr));
        loginButton->setText(QCoreApplication::translate("Login", "Login", nullptr));
        label->setText(QCoreApplication::translate("Login", "Database Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
