#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "additemdialog.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QDebug>
#include <QMessageBox>

QString userRoleCheck, usrID, usrPin;

MainWindow::MainWindow(QString userRole, QString userID, QString userPin, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , manager(new QNetworkAccessManager(this))
    , currentUserRole(userRole)
    , currentUserID(userID)
    , currentUserPin(userPin)
{
    ui->setupUi(this);
    userRoleCheck = currentUserRole;
    usrID = currentUserID;
    usrPin = currentUserPin;

    if(userRoleCheck.trimmed() == "Faculty")
    {
        ui->currentRoleLabel->setText("Current Role: Faculty");
        ui->deleteButton->hide();
        ui->deleteItemIdInput->hide();
    }

    else if(userRoleCheck.trimmed() == "Student")
    {
        ui->currentRoleLabel->setText("Current Role: Student");
        ui->deleteButton->hide();
        ui->deleteItemIdInput->hide();
        ui->pushButton->hide();
        ui->idInput->hide();
        ui->editQtySpinBox->hide();
        ui->editButton->hide();
    }

    else if(userRoleCheck.trimmed() == "Admin")
    {
        ui->currentRoleLabel->setText("Current Role: Admin");
    }


}

MainWindow::~MainWindow()
{
    delete ui;
}

// Add item button handler
void MainWindow::on_pushButton_clicked()
{
    AddItemDialog dialog(this);

    if(dialog.exec() == QDialog::Accepted)
    {
        // Obtain User ID and Pin
        QString name = dialog.getName();  // Obtains name
        int qty = dialog.getQuantity();  // Obtains quantity
        QJsonObject obj;  // Store name and qty in a Json object
        obj["id"] = usrID;
        obj["pin"] = usrPin;
        obj["name"] = name;
        obj["quantity"] = qty;
        QJsonDocument doc(obj);
        QByteArray data = doc.toJson();  // Parses received data into Json data

        QUrl url("http://localhost:18080/items");
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        QNetworkReply *reply = manager->post(request, data);

        connect(reply, &QNetworkReply::finished, this, [=]()
        {
            if(reply->error() == QNetworkReply::NoError)
            {
                QByteArray responseData = reply->readAll();
                QMessageBox::information(this, "Item Added", "Server returned: \n\n" + responseData);
                ui->outputBox->setPlainText("");
                ui->outputBox->setPlainText(QString::fromUtf8(responseData));  // Display as plain text
            }

            else
            {
                QMessageBox::warning(this, "Error", reply->errorString());
            }

            reply->deleteLater();
        });
        qDebug("Name. %s" , name.toStdString().c_str());
        qDebug("Quantity. %d" , qty);
    }
}

// Load button handler
void MainWindow::on_loadButton_clicked()
{
    // GET request
    QUrl url("http://localhost:18080/items");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QNetworkReply *reply = manager->get(request);

    connect(reply, &QNetworkReply::finished, this, [=]()
    {
        // If a reply is received
        if(reply->error() == QNetworkReply::NoError)
        {
            QByteArray responseData = reply->readAll();
            ui->outputBox->setPlainText("");
            ui->outputBox->setPlainText(QString::fromUtf8(responseData));  // Display as plain text
        }

        else
        {
            QMessageBox::warning(this, "GET Failed", reply->errorString());
        }

        reply->deleteLater();
    });

}

// Edit button handler
void MainWindow::on_editButton_clicked()
{
    // Obtain item ID and quantity
    QString itemID = ui->idInput->text().trimmed();
    int newQty = ui->editQtySpinBox->value();
    QJsonObject obj;
    obj["id"] = usrID;
    obj["pin"] = usrPin;
    obj["quantity"] = newQty;

    // Convert user input to JSON data
    QJsonDocument doc(obj);
    QByteArray data = doc.toJson();

    // PATCH request
    QUrl url("http://localhost:18080/items/" + itemID);
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QNetworkReply *reply = manager->sendCustomRequest(request, "PATCH", data);

    connect(reply, &QNetworkReply::finished, this, [=]()
    {
        // If a reply is received
        if(reply->error() == QNetworkReply::NoError)
        {
            QMessageBox::information(this, "Success", "Quantity updated successfully.");
            on_loadButton_clicked();  // Call loadButton clicked handler to refresh item list
        }

        else
        {
            QMessageBox::warning(this, "PATCH Failed", reply->errorString());
        }

        reply->deleteLater();
    });

}

void MainWindow::on_deleteButton_clicked()
{
    // Obtain item ID, user ID, and quantity
    QString itemId = ui->deleteItemIdInput->text().trimmed();
    QJsonObject obj;
    obj["id"] = usrID;
    obj["pin"] = usrPin;

    // Convert user input to JSON data
    QJsonDocument doc(obj);
    QByteArray data = doc.toJson();

    // DELETE request
    QUrl url("http://localhost:18080/items/" + itemId);
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QNetworkReply *reply = manager->sendCustomRequest(request, "DELETE", data);

    connect(reply, &QNetworkReply::finished, this, [=]()
    {
        // If a reply is received
        if(reply->error() == QNetworkReply::NoError)
        {
            QMessageBox::information(this, "Success", "Quantity deleted successfully (Deactivated).");
            on_loadButton_clicked();  // Call loadButton clicked handler to refresh item list
        }

        else
        {
            QMessageBox::warning(this, "DELETE Failed", reply->errorString());
        }

        reply->deleteLater();
    });
}

