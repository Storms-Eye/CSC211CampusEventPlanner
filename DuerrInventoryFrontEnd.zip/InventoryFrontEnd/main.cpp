#include "mainwindow.h"
#include "login.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login loginWindow;

    // Prompt user to log in before continuing
    if((loginWindow.exec() == QDialog::Accepted))
    {
        MainWindow w(loginWindow.getUserRole(), loginWindow.getUserID(), loginWindow.getUserPin());
        w.show();
        return a.exec();
    }

    return 0;
}
