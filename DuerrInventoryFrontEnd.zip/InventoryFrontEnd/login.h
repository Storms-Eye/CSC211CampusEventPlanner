#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QNetworkAccessManager>

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();
    bool isLoggedIn();
    QString getUserRole();
    QString getUserID();
    QString getUserPin();

private slots:
    void on_loginButton_clicked();

private:
    Ui::Login *ui;
    QNetworkAccessManager *manager;
    QString userRole;
};

#endif // LOGIN_H
